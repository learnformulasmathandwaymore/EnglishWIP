# PolyModLoader
![pipeline](https://ci.codeberg.org/api/badges/14762/status.svg)

PolyModLoader is a community developed mod loader for the game PolyTrack.

[[Wiki|../../../wiki]] | [PolyTrack Discord Server](https://discord.gg/g5Tr6Ysfh7) | [PolyTrack modding Discord server](https://discord.gg/GfQzuqudCg)